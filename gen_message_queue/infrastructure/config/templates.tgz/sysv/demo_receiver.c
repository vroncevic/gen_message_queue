/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * demo_receiver.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

#include <signal.h>
#include "mq_sysv.h"

#define IPC_FILE_PATH "/tmp"
#define IPC_PROJECT_ID 'M'

static volatile sig_atomic_t g_running = 1;

static void handle_signal(int sig)
{
    (void)sig;
    g_running = 0;
}

int main(void)
{
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);

    printf("[Receiver] Generating IPC key from path: %s\n", IPC_FILE_PATH);
    key_t key = mq_sysv_file_to_key(IPC_FILE_PATH, IPC_PROJECT_ID);
    if (key == MQ_SYSV_ERROR)
    {
        perror("[Receiver] Failed to generate IPC key");
        return 1;
    }

    printf("[Receiver] Obtaining/creating message queue ID for key: 0x%08x\n", key);
    int mq_id = mq_sysv_key_to_id(key, MQ_SYSV_SENDER);
    if (mq_id == MQ_SYSV_ERROR)
    {
        perror("[Receiver] Failed to access/create message queue");
        return 1;
    }

    printf("[Receiver] Connected to message queue ID: %d\n", mq_id);
    printf("[Receiver] Listening for messages (press Ctrl+C or send 'exit' to quit)...\n");

    mq_buffer buf;
    int count = 0;

    while (g_running)
    {
        int bytes = mq_sysv_receive(mq_id, &buf, 0, 0);
        if (bytes < 0)
        {
            if (errno == EINTR)
            {
                printf("\n[Receiver] Interrupted by signal. Shutting down.\n");
                break;
            }
            perror("[Receiver] Error while receiving message");
            break;
        }

        count++;
        const char *msg_text = mq_sysv_get_buffer(&buf);
        printf("[Receiver] Message #%d (type %ld, %d bytes): '%s'\n",
               count, mq_sysv_get_buffer_type(&buf), bytes, msg_text);

        if (strcmp(msg_text, "exit") == 0)
        {
            printf("[Receiver] Received 'exit' command. Shutting down.\n");
            break;
        }
    }

    printf("[Receiver] Removing message queue ID: %d from kernel.\n", mq_id);
    if (mq_sysv_remove(mq_id) == MQ_SYSV_ERROR)
    {
        perror("[Receiver] Failed to remove message queue");
    }
    else
    {
        printf("[Receiver] Queue successfully removed.\n");
    }

    return 0;
}
