/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * mq_sysv_send.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mq_sysv.h"

/**
 * Description:
 *     Deliver a message to a queue.
 *
 * Arguments:
 *     mq_id - message queue id
 *     buffer - message queue buffer
 *
 * Return value:
 *     status - 0 for success | MQ_SYSV_ERROR with error number:
 *                  EAGAIN, EACCES, EFAULT, EIDRM, EINTR, EINVAL, ENOMEM
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_sysv_send(int mq_id, mq_buffer *buffer)
{
    int status;

    if (mq_id >= 0 && buffer != NULL)
    {
        status = msgsnd(
            mq_id, buffer, strlen(buffer->message_buffer) + 1, 0
        );
    }
    else
    {
        status = MQ_SYSV_ERROR;
    }

    return status;
}
