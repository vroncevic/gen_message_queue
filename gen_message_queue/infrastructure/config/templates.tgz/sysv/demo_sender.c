/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * demo_sender.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

#include "mq_sysv.h"

#define IPC_FILE_PATH "/tmp"
#define IPC_PROJECT_ID 'M'

int main(int argc, char *argv[])
{
    printf("[Sender] Generating IPC key from path: %s\n", IPC_FILE_PATH);
    key_t key = mq_sysv_file_to_key(IPC_FILE_PATH, IPC_PROJECT_ID);
    if (key == MQ_SYSV_ERROR)
    {
        perror("[Sender] Failed to generate IPC key");
        return 1;
    }

    printf("[Sender] Obtaining/creating message queue ID for key: 0x%08x\n", key);
    int mq_id = mq_sysv_key_to_id(key, MQ_SYSV_SENDER);
    if (mq_id == MQ_SYSV_ERROR)
    {
        perror("[Sender] Failed to create/get message queue");
        return 1;
    }

    printf("[Sender] Message queue opened with ID: %d\n", mq_id);

    if (argc > 1)
    {
        long msg_type = (argc > 2) ? atol(argv[2]) : 1;
        mq_buffer buf;
        mq_sysv_set_buffer_type(&buf, msg_type);
        mq_sysv_set_buffer(&buf, argv[1]);

        printf("[Sender] Sending custom message (type %ld): '%s'\n", msg_type, argv[1]);
        if (mq_sysv_send(mq_id, &buf) == MQ_SYSV_ERROR)
        {
            perror("[Sender] Failed to send message");
        }
    }
    else
    {
        const char *messages[] = {
            "First System V message (type 1)",
            "Second System V message (type 2)",
            "Third System V urgent message (type 1)"
        };
        long types[] = {1, 2, 1};

        for (int i = 0; i < 3; i++)
        {
            mq_buffer buf;
            mq_sysv_set_buffer_type(&buf, types[i]);
            mq_sysv_set_buffer(&buf, messages[i]);

            printf("[Sender] Sending message type %ld: '%s'\n", types[i], messages[i]);
            if (mq_sysv_send(mq_id, &buf) == MQ_SYSV_ERROR)
            {
                perror("[Sender] Failed to send message");
            }
        }

        printf("[Sender] All default messages successfully queued.\n");
        printf("[Sender] Usage hint: %s <message> [type] (send 'exit' to stop receiver)\n", argv[0]);
    }

    return 0;
}
