/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * mq_sysv_set_buffer.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mq_sysv.h"

/**
 * Description:
 *     Set message queue buffer.
 *
 * Arguments:
 *     buffer - message queue buffer
 *     message_buffer - message buffer
 *
 * Return value:
 *     none
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
void mq_sysv_set_buffer(mq_buffer * buffer, char * message_buffer)
{
    if (buffer != NULL)
    {
        buffer->message_buffer = message_buffer;
    }
}

