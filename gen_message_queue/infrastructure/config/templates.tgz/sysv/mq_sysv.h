/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * mq_sysv.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>

#define MQ_SYSV_BUFFER_RWX_RXX_RXX 0644
#define MQ_SYSV_SENDER 0x00000001
#define MQ_SYSV_RECEIVER 0x00000002
#define MQ_SYSV_ERROR (-1)

#define MQ_FLAG_ZERO 0
#define MQ_IPC_NOWAIT IPC_NOWAIT

#define MQ_SYSV_BUFFER_SIZE 1024

/**
 * MQ Buffer structure
 *
 *     message_type - capability to multiplex messages on a single queue
 *     message_buffer - contiguous character payload buffer
 */
typedef struct
{
    long message_type;
    char message_buffer[MQ_SYSV_BUFFER_SIZE];
} mq_buffer;

/**
 * Description:
 *     Convert a pathname and a key to a System V IPC key.
 *
 * Arguments:
 *     file_path - path name
 *     key - key id (which must be nonzero)
 *
 * Return value:
 *     mq_key - system V IPC key or -1 on failure
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
key_t mq_sysv_file_to_key(const char *file_path, int key);

/**
 * Description:
 *     Convert System V IPC key to message queue id.
 *
 * Arguments:
 *     mq_key - system V IPC key
 *     operation - message queue operation (MQ_SYSV_SENDER or MQ_SYSV_RECEIVER)
 *
 * Return value:
 *     mq_id - message queue id | MQ_SYSV_ERROR
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_sysv_key_to_id(key_t mq_key, int operation);

/**
 * Description:
 *     Set message queue buffer type.
 *
 * Arguments:
 *     buffer - message queue buffer
 *     message_type - message queue type
 *
 * Return value:
 *     none
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
void mq_sysv_set_buffer_type(mq_buffer *buffer, long message_type);

/**
 * Description:
 *     Get message queue buffer type.
 *
 * Arguments:
 *     buffer - message queue buffer
 *
 * Return value:
 *     message_type - message queue type
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
long mq_sysv_get_buffer_type(mq_buffer *buffer);

/**
 * Description:
 *     Set message queue buffer payload.
 *
 * Arguments:
 *     buffer - message queue buffer
 *     message_buffer - message payload to copy
 *
 * Return value:
 *     none
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
void mq_sysv_set_buffer(mq_buffer *buffer, const char *message_buffer);

/**
 * Description:
 *     Get message queue buffer payload.
 *
 * Arguments:
 *     buffer - message queue buffer
 *
 * Return value:
 *     message_buffer - pointer to message payload
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
char *mq_sysv_get_buffer(mq_buffer *buffer);

/**
 * Description:
 *     Removes a message from the queue specified by mq_id and places
 *     it in the buffer pointer.
 *
 * Arguments:
 *     mq_id - message queue id
 *     buffer - message queue buffer
 *     message_type - specifies the type of message requested
 *     message_flag - bit mask flags (0 or IPC_NOWAIT)
 *
 * Return value:
 *     status - number of bytes copied | MQ_SYSV_ERROR on failure
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_sysv_receive(int mq_id, mq_buffer *buffer, long message_type, int message_flag);

/**
 * Description:
 *     Deliver a message to a queue.
 *
 * Arguments:
 *     mq_id - message queue id
 *     buffer - message queue buffer
 *
 * Return value:
 *     status - 0 for success | MQ_SYSV_ERROR on failure
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_sysv_send(int mq_id, mq_buffer *buffer);

/**
 * Description:
 *     Perform control operations on a message queue.
 *
 * Arguments:
 *     mq_id - message queue id
 *     command - control command (IPC_STAT, IPC_SET, IPC_RMID)
 *     buffer - message queue buffer struct msqid_ds
 *
 * Return value:
 *     status - 0 for success | MQ_SYSV_ERROR for failure
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_sysv_control(int mq_id, int command, struct msqid_ds *buffer);

/**
 * Description:
 *     Removes a message queue from the kernel.
 *
 * Arguments:
 *     mq_id - message queue id
 *
 * Return value:
 *     status - 0 for success | MQ_SYSV_ERROR for failure
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_sysv_remove(int mq_id);

#ifdef __cplusplus
}
#endif
