/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * mq_sysv_receive.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mq_sysv.h"

/**
 * Description:
 *     Removes a message from the queue specified by mq_id and places
 *     it in the buffer pointer.
 *
 * Arguments:
 *     mq_id - message queue id
 *     buffer - message queue buffer
 *     message_type - specifies the type of message requested
 *     message_flag - bit mask flags (0 or IPC_NOWAIT)
 *
 * Return value:
 *     status - number of bytes actually copied | MQ_SYSV_ERROR with error number:
 *                  E2BIG, EACCES, EAGAIN, EFAULT, EIDRM, EINTR, EINVAL, ENOMSG
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_sysv_receive(int mq_id, mq_buffer *buffer, long message_type, int message_flag)
{
    int status;

    if (mq_id >= 0 && buffer != NULL)
    {
        status = msgrcv(
            mq_id, buffer, sizeof(buffer->message_buffer),
            message_type, message_flag
        );
    }
    else
    {
        status = MQ_SYSV_ERROR;
    }

    return status;
}
