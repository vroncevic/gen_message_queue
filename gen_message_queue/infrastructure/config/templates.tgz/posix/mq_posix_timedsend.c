/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * mq_posix_timedsend.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mq_posix.h"

/**
 * Description:
 *     Adds a message to the message queue with a timeout limit.
 *
 * Arguments:
 *     mq_descriptor - message queue descriptor
 *     message - message buffer to send
 *     message_length - length of message
 *     message_priority - priority of message
 *     abs_timeout - absolute timeout specification
 *
 * Return value:
 *     status - on success returns 0 | MQ_POSIX_ERROR on failure
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_posix_timedsend(
    mqd_t mq_descriptor, const char *message,
    size_t message_length, unsigned int message_priority,
    const struct timespec *abs_timeout
)
{
    int status;

    if (
        mq_descriptor != MQ_POSIX_ERROR &&
        message != NULL &&
        abs_timeout != NULL
    )
    {
        status = mq_timedsend(
            mq_descriptor, message, message_length,
            message_priority, abs_timeout
        );
    }
    else
    {
        status = MQ_POSIX_ERROR;
    }

    return status;
}
