/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * mq_posix_setattr.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mq_posix.h"

/**
 * Description:
 *     Modifies attributes of the message queue referred to by mq_descriptor.
 *
 * Arguments:
 *     mq_descriptor - message queue descriptor
 *     new_attr - pointer to new attributes (e.g. O_NONBLOCK)
 *     old_attr - pointer to store previous attributes (can be NULL)
 *
 * Return value:
 *     status - on success returns 0 | MQ_POSIX_ERROR on failure
 *
 * Standards:
 *     POSIX.1-2001, POSIX.1-2008
 */
int mq_posix_setattr(
    mqd_t mq_descriptor, const struct mq_attr *new_attr,
    struct mq_attr *old_attr
)
{
    int status;

    if (mq_descriptor != MQ_POSIX_ERROR && new_attr != NULL)
    {
        status = mq_setattr(mq_descriptor, new_attr, old_attr);
    }
    else
    {
        status = MQ_POSIX_ERROR;
    }

    return status;
}
