/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * demo_receiver.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

#include "mq_posix.h"

#define QUEUE_NAME "/${PRO}_posix_queue"
#define MAX_MESSAGES 10
#define MAX_MSG_SIZE 256

static volatile sig_atomic_t g_running = 1;

static void handle_signal(int sig)
{
    (void)sig;
    g_running = 0;
}

int main(void)
{
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);

    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = MAX_MESSAGES;
    attr.mq_msgsize = MAX_MSG_SIZE;
    attr.mq_curmsgs = 0;

    printf("[Receiver] Opening/creating message queue: %s\n", QUEUE_NAME);
    mqd_t mq = mq_posix_open_mode(
        QUEUE_NAME,
        O_CREAT | O_RDONLY,
        0644,
        &attr
    );

    if (mq == MQ_POSIX_ERROR)
    {
        mq_posix_fatal_error("[Receiver] Failed to open/create message queue");
    }

    if (mq_posix_getattr(mq, &attr) == MQ_POSIX_ERROR)
    {
        mq_posix_fatal_error("[Receiver] Failed to get queue attributes");
    }

    printf("[Receiver] Queue attributes: maxmsg=%ld, msgsize=%ld, curmsgs=%ld\n",
           attr.mq_maxmsg, attr.mq_msgsize, attr.mq_curmsgs);

    char *buffer = (char *)malloc(attr.mq_msgsize);
    if (buffer == NULL)
    {
        perror("[Receiver] Failed to allocate receive buffer");
        mq_posix_close(mq);
        exit(1);
    }

    printf("[Receiver] Listening for messages (press Ctrl+C or send 'exit' to quit)...\n");

    while (g_running)
    {
        unsigned int priority = 0;
        ssize_t bytes_read = mq_posix_receive(mq, buffer, attr.mq_msgsize, &priority);

        if (bytes_read >= 0)
        {
            if ((size_t)bytes_read < (size_t)attr.mq_msgsize)
            {
                buffer[bytes_read] = '\0';
            }
            else
            {
                buffer[attr.mq_msgsize - 1] = '\0';
            }

            printf("[Receiver] Received (bytes: %zd, priority: %u): '%s'\n",
                   bytes_read, priority, buffer);

            if (strcmp(buffer, "exit") == 0)
            {
                printf("[Receiver] Received 'exit' command. Shutting down.\n");
                break;
            }
        }
        else
        {
            if (errno == EINTR)
            {
                printf("\n[Receiver] Interrupted by signal. Shutting down.\n");
                break;
            }
            perror("[Receiver] Failed to receive message");
            break;
        }
    }

    free(buffer);
    mq_posix_close(mq);

    printf("[Receiver] Cleaning up and unlinking message queue: %s\n", QUEUE_NAME);
    mq_posix_unlink(QUEUE_NAME);

    return 0;
}
