/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * demo_sender.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

#include "mq_posix.h"

#define QUEUE_NAME "/${PRO}_posix_queue"
#define MAX_MESSAGES 10
#define MAX_MSG_SIZE 256

int main(int argc, char *argv[])
{
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = MAX_MESSAGES;
    attr.mq_msgsize = MAX_MSG_SIZE;
    attr.mq_curmsgs = 0;

    printf("[Sender] Opening/creating message queue: %s\n", QUEUE_NAME);
    mqd_t mq = mq_posix_open_mode(
        QUEUE_NAME,
        O_CREAT | O_WRONLY,
        0644,
        &attr
    );

    if (mq == MQ_POSIX_ERROR)
    {
        mq_posix_fatal_error("[Sender] Failed to open/create message queue");
    }

    if (argc > 1)
    {
        const char *custom_msg = argv[1];
        unsigned int priority = (argc > 2) ? (unsigned int)atoi(argv[2]) : 10;

        printf("[Sender] Sending custom message: '%s' with priority %u\n", custom_msg, priority);
        if (mq_posix_send(mq, custom_msg, strlen(custom_msg) + 1, priority) == MQ_POSIX_ERROR)
        {
            perror("[Sender] Failed to send message");
        }
    }
    else
    {
        const char *messages[] = {
            "Standard telemetry packet (priority 1)",
            "Critical emergency alarm (priority 30)",
            "Periodic heartbeat ping (priority 5)"
        };
        unsigned int priorities[] = {1, 30, 5};

        for (int i = 0; i < 3; i++)
        {
            printf("[Sender] Sending: '%s' with priority %u\n", messages[i], priorities[i]);
            if (mq_posix_send(mq, messages[i], strlen(messages[i]) + 1, priorities[i]) == MQ_POSIX_ERROR)
            {
                perror("[Sender] Failed to send message");
            }
        }
        printf("[Sender] All default messages sent.\n");
        printf("[Sender] Usage hint: %s <message> [priority] (send 'exit' to stop receiver)\n", argv[0]);
    }

    mq_posix_close(mq);
    return 0;
}
